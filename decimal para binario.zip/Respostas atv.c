1- 	a) Decimal: 37, Hexadecimal: (falha no dev)
	b) Decimal: 557, Hexadecimal: (falha no dev)
	c) Decimal: 0 (erro no c�digo), Hexadecimal: (falha no dev)
	
2- 	a) Binario: 100101001, hexadecimal:
	b) Binario: 111110110101, hexadecimal:
	c) Binario: 10001110101111, hexadecimal: 
	
	Quest�o 2 falha na compila��o do dev, n�o compila c�digos em "For"
	
3-	a) Binario: 1997, n�o consegui fazer o c�digo em decimal
	b) Binario: 39027, n�o consegui fazer o c�digo em decimal
	c) Binario: 193963, n�o consegui fazer o c�digo em decimal
